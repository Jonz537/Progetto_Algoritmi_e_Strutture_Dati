#set page(margin: (
  top: 2cm,
  bottom: 1.5cm,
  left: 2cm,
  right: 1.8cm
))
//#set par(justify: true) 
#set par(leading: .68em, justify: true) //Interlinea
#set underline(
  stroke: .9pt,
  offset: 1.8pt,
  extent: 0pt,
  evade: true,
)
#show math.equation: set text(13pt)
//#set text(size:16pt); #align(center)[#underline[*ALGORITMI & STRUTTURE DATI*] ]

#show heading: set text(size:16pt/* , font: "Liberation Sans" */, fill: rgb("#000077"))

#set raw(
  syntaxes: "pseudocode.sublime-syntax",
  theme: "pseudocode.tmTheme",
)
#show raw: set text(size: 11pt, font: "Cascadia Code")

#show raw.where(block: true): code => {
  show "§": linebreak() // Sostituzione del marcatore § con un a-capo visivo

  show raw.line: line => {
    text(fill: gray)[#line.number]
    h(1em)
    line.body
  }

  code
}

#set text(lang: "it")

#show link: it => underline(
  stroke: (thickness: 1pt,  paint: gray.darken(40%), dash: "dotted"),
  emph(it)
)

#show figure.where(
  kind: table
): set figure.caption(position: top)

#show table: it => block(breakable: false, it)
//#show raw: it => block(breakable: false, it)


// PRIMA PAGINA
#align(horizon + center)[#set text(size:28pt)
*Relazione del progetto per il corso \"Algoritmi e Strutture Dati\"* \
]
#align(center)[
#set text(size:15pt)
Applicazione del paradigma della progettazione dinamica al problema di ricerca della sottosequenza comune di lunghezza massima fra due stringhe/sequenze (Longest Common Subsequence)
]

#set text(size:18pt)
#align(bottom + center)[
_#underline[Saleri Giorgio, Viola Luca]_]


#pagebreak()
// Indice

#set text(size:13pt)//, font:"Linux Libertine")

#outline(title: "Indice")


\ \ //INIZIO Relazione
= Presentazione del problema (LCS)
Il problema della massima sottosequenza comune (_longest common subsequence_) consiste nel trovare la sottosequenza di lunghezza massima comune a due stringhe di input.

Una sottosequenza di una stringa è una nuova stringa generata dall'originale, alla quale sono stati rimossi zero o più elementi, mantenendo però l'ordine relativo dei caratteri rimanenti.

*Definizione di sottosequenza*:\ 
Data la stringa $X=chevron x_1x_2,...,x_n chevron.r$, un'altra stringa $Z = chevron z_1, z_2 ,...,z_k chevron.r$ è detta sottosequenza di $X$ se $exists space chevron i_1, i_2, i_k chevron.r$ di indici di $X$ tale che $forall j=1,2,...,k space$ si ha $space x_i_j=z_j$.

*Definizione di sottosequenza comune*: \
Date due sequenze $X$ e $Y$, diciamo che una sequenza $Z$ è sottosequenza comune di $X$ e $Y$ se $Z$ è una sottosequenza di entrambe $X$ ed $Y$.

*Definizione del problema*:\
Date due stringhe $X=chevron x_1 , x_2, ..., x_m chevron.r $ e $Y= chevron y_1, y_2, ..., y_n chevron.r$, trovare la sottosequenza di lunghezza maggiore $Z=chevron z_1, z_2, ...,z_k chevron.r$ comune a $X$ e $Y$.

_Da qui in poi ogni volta LCS = "più lunga sottosequenza comune" _ 

*Applicazioni dell'algoritmo*
- Grado di parentela tra due specie: si analizzano sequenze di DNA delle due specie con LCS per controllare quanto queste siano simili, e quindi determinarne il legame di parentela delle specie;  
- Sistemi di controllo di versione: ad esempio in _git_ viene utilizzato il principio alla base di LCS per la gestione dei merge;
- Correzione ortografica: viene sfruttato LCS per facilitare il calcolo della distanza di edit utilizzata per i correttori automatici.

#set heading(numbering: "1."); \
= Caratterizzazione della struttura di una soluzione ottima //Fase 1
La soluzione più ingenua al problema ovviamente è quella di enumerare tutte le sottosequenze della prima stringa $X$ e controllare singolarmente se queste sono anche sottosequenze della seconda stringa $Y$, tenendo nel frattempo traccia della sottosequenza comune più lunga trovata. \ Una stringa $X$ composta da $m$ caratteri ha al suo interno $2^m$ possibili sottosequenze (ogni sottosequenza corrisponde ad un sottoinsieme degli indici di $X$), perciò questo approccio richiede un tempo esponenziale e non è applicabile al problema in modo generale. \
\
Per caratterizzare matematicamente la soluzione è comodo definire il concetto di \"prefisso\": data la sequenza $X=chevron x_1 , x_2, ..., x_m chevron.r$, l'*i-esimo prefisso di X* è la sottosequenza \ $X_i =chevron x_1 , x_2, ..., x_i chevron.r$. 
Quindi l'i-esimo prefisso è la sottosequenza che include i primi $i$ elementi di $X$ ($X_0$ è la stringa vuota). \

Questo problema gode della proprietà della sottostruttura ottima: le classi di sottoproblemi si possono rappresentare come coppie di prefissi delle due sequenze di input. Il problema complessivo è riducibile in sottoproblemi partendo dalle stringhe intere ed andando man mano ad analizzare i prefissi sempre più brevi.

*Teorema*: #h(.2cm)
Siano $X=chevron x_1 , x_2, ..., x_m chevron.r $ e $Y= chevron y_1, y_2, ..., y_n chevron.r$ due sequenze di input e sia \ $Z=chevron z_1 , z_2, ..., z_k chevron.r$ una qualsiasi più lunga sottosequenza comune di $X, Y$ (non è detto che $Z$ sia l'unica sottosequenza comune).

+ Se $space x_m = y_n space$ allora $space z_k = x_m = y_n space$ e quindi $Z_(k-1)$ è una più lunga sottosequenza comune di $X_(m-1), Y_(n-1)$ 

+ Se $x_m != y_n space$ e $space z_k != x_m space $ allora $Z$ è una più lunga sottosequenza comune di $X_(m-1), Y$ 

+ Se $x_m != y_n space$ e $space z_k != y_n space $ allora $Z$ è una più lunga sottosequenza comune di $X, Y_(n-1)$ 
// x_m, y_n, z_k sono i caratteri finali delle rispettive stringhe

//[Dimostrazione ????]

Questo teorema è fondamentale per procedere con la definizione ricorsiva di una soluzione e spiega come si può scomporre il problema in problemi di dimensione minori garantendo che le loro soluzioni siano utili per costruire la soluzione ottima del problema originale. \
Una LCS di due stringhe contiene al suo interno una LCS di certi prefissi delle due stringhe (ovvero il problema gode della proprietà della sottostruttura ottima e quindi si potrà costruire la LCS a partire da sottosequenze comuni minori).

// Nel 1° caso se gli ultimi caratteri delle stringhe corrispondono a quello della sottosequenza allora il suo ultimo carattere è comune e posso ridurre di uno la dimensione del problema "consumando" questo carattere. \
// Nel 2°/3° caso i caratteri non corrispondono quindi controllo a quale stringa appartiene l'ultimo carattere della sottosequenza comune e posso ridurre di uno la dimensione della stringa a cui l'ultimo carattere non appartiene.

\
= Definizione ricorsiva del valore di una soluzione ottima  // Fase 2
Il teorema ci indica che ci sono uno o due sottoproblemi da analizzare per trovare una più lunga sottosequenza comune di $X, Y$. \ 
Nel primo caso in cui gli ultimi caratteri delle due stringhe corrispondono ($x_m = y_n$) \ dobbiamo trovare la LCS di $X_(m-1), Y_(n-1)$, ovvero le stringhe senza l'ultimo carattere. \
Nel caso in cui invece gli ultimi caratteri non corrispondono si vanno a risolvere due \ sottoproblemi ovvero trovare la LCS sia di $X_(m-1), Y$, che di $X, Y_(n-1)$. \ La più lunga tra le due sottosequenze trovate risolvendo questi problemi è una LCS di $X, Y$. \
Questi casi coprono tutte le possibilità e perciò si può concludere che all'interno della LCS di $X, Y$ si deve sicuramente usare una delle soluzioni ottime dei sottoproblemi. \

Inoltre questo problema presenta il tipico caso di sottoproblemi sovrapposti, ovvero al fine di trovare la LCS si risolvono più volte gli stessi sottoproblemi (ad esempio se devo trovare la LCS di $X, Y_(n-1)$ andrò a cercare nuovamente la LCS di $X_(m-1), Y_(n-1)$). 
// Procedendo con una strategia top-down è quindi evidente che si vanno a ripetere calcoli già fatti in precedenza.
È necessario definire una ricorrenza per il valore di una soluzione ottima affinché il problema sia risolvibile in modo ricorsivo.

Si definisce quindi $c[i, j]$ come la lunghezza di una più lunga sottosequenza comune delle stringhe $X_i, Y_j$. Se $i = 0, j = 0$, si intende che una delle sequenze ha lunghezza 0 e quindi la LCS è una stringa vuota (anch'essa di lunghezza 0). \
Con questa definizione è possibile definire la formula ricorsiva
$ c[i, j] = cases( 0 #h(5.8cm) "se " i = 0 " o " j = 0,
                  c[i-1, j-1]+1 #h(2.65cm) "se " i\, j>0 "e" x_i=y_j,
                  max{c[i, j-1]," "c[i-1, j]} #h(0.745cm) "se " i\, j>0 "e" x_i != y_j
) $

In questa formulazione ricorsiva è racchiuso il caso base per la lunghezza nulla ed i due casi visti prima con il teorema. \

// Non è detto che qualunque sottoproblema venga analizzato, dato che ci sono delle condizioni nella formulazione ricorsiva che non riguardano solo il caso base, è possibile arrivare alla soluzione ottima senza aver esplorato tutti i sottoproblemi (viene risolto uno o l'altro per come è costruita la formula).




\
= Calcolo del valore di una soluzione ottima //con una strategia bottom-up  // Fase 3
Usando l'equazione sopra definita si potrebbe scrivere facilmente un algoritmo ricorsivo per calcolare la lunghezza della LCS in modo top-down che però richiederebbe un tempo esponenziale vista la ripetizione dei sottoproblemi. \

Invece di ripetere i calcoli con tutte le possibili sottosequenze si costruisce una tabella che risolve i sottoproblemi di dimensione minore e li combina man mano per arrivare alla soluzione completa in tempo polinomiale.
Il problema complessivo però ha solo $Theta(m dot n)$ sottoproblemi differenti dato che dobbiamo calcolare $c[i, j] space$ per $space 0<=i<=m, space 0<=j<=n$. \
Si può quindi usare la programmazione dinamica per calcolare le soluzioni in modo bottom-up

`LCS-LENGTH(X, Y)`
```pseudo
m = length[X]
n = length[Y]
Sia c[0...m, 0...n] una nuova tabella per i valori
Sia b[1...m, 1...n] una nuova tabella per le scelte (direzioni) §
for i = 0 to m  do c[i, 0] = 0   // Inizializzazione dei casi base
for j = 0 to n  do c[0, j] = 0   // (colonna 0 e riga 0 a zero) §
for i = 1 to m        // Riempimento iterativo bottom-up riga per riga  
   do for j = 1 to n
      do if X[i] == Y[j]
          then c[i, j] = c[i-1, j-1] + 1
               b[i, j] = '↖'            //salva provenienza diagonale
         else if c[i-1, j] >= c[i, j-1]
            then c[i, j] = c[i-1, j]
                 b[i, j] = '↑'          //salva provenienza dall'alto
         else c[i, j] = c[i, j-1]
              b[i, j] = '←'         //salva la provenienza da sinistra
return c, b
```


`LCS-LENGTH` memorizza i valori `c[i, j]` in una tabella `c[0...m, 0...n]` e ne calcola gli elementi riga per riga riempiendo la prima riga da sinistra a destra, poi la seconda riga e così via fino all'ultima. \
Viene utilizzata anche la tabella `b[1...m, 1...n]` che semplifica la costruzione della soluzione ottima, `b[i, j]` punta al valore della tabella che corrisponde alla soluzione ottima del sottoproblema che è stato scelto per calcolare `c[i, j]` (è la tabella che contiene le frecce). \
`LCS-LENGTH` al termine restituisce entrambe le tabelle e nella cella `c[m, n]` si trova la lunghezza di una LCS di $X, Y$, mentre partendo dalla cella `b[m, n]` si ricostruisce il percorso per individuare la LCS.

*Complessità temporale e spaziale* \
Il calcolo di ogni elemento della tabella richiede un tempo costante $Theta(1)$, questa istruzione si trova annidata all'interno di due cicli che vengono eseguiti rispettivamente per $m, n$ iterazioni e perciò il tempo di esecuzione dell'algoritmo `LCS-LENGTH` è proporzionale al numero di iterazioni $space T(n) = Theta(m dot n)$.

La complessità spaziale è $Theta(m dot n)$, cioè lo spazio necessario per istanziare le due tabelle in memoria, le singole stringhe passate in input occupano meno spazio delle tabelle che costituiscono l'occupazione di memoria dominante. Essendo un algoritmo iterativo lo spazio in memoria necessario per la pila dei contesti è $Theta(1)$, quindi non influisce sulla complessità spaziale totale.

\
= Costruzione della soluzione ottima  // Fase 4
Grazie alla tabella `b` restituita dall'algoritmo si può velocemente costruire una LCS di $X, Y$. \
Si inizia da `b[m, n]` e si attraversa la tabella seguendo le frecce, ogni volta che si incontra una freccia diagonale in `b[i, j]` allora l'elemento $x_i = y_j$ appartiene alla  LCS trovata dall'algoritmo. Così facendo si incontrano gli elementi della LCS in ordine inverso e la si costruisce per intero, dato che a riga 5 la stampa avviene dopo la chiamata ricorsiva, i caratteri della LCS vengono stampati nell'ordine corretto. (prima si esplora la tabella con le chiamate ricorsive incontrando gli elementi in ordine inverso e poi al ritorno li si stampa) \

// approfondire analisi

`PRINT-LCS(b, X, i, j)````pseudo    // chiamata iniziale: PRINT-LCS(b, X, m, n)```
```pseudo
if i == 0 or j == 0  return        // la LCS è la stringa vuota §
if b[i, j] = '↖'                   //diagonale
   PRINT-LCS(b, X, i-1, j-1)
   stampa X[i] §
else if b[i, j] = '↑'
   PRINT-LCS(b, X, i-1, j) §
else PRINT-LCS(b, X, i, j-1)
```
*Complessità temporale*\
L'algoritmo `PRINT-LCS` stampa una LCS di $X, Y$ con gli elementi in ordine di indice crescente.
La stampa richiede un tempo $O(m+n)$ perchè ad ogni chiamata ricorsiva decrementa almeno uno tra i contatori $i, j$ e quindi le operazioni a tempo costante presenti nell'algoritmo vengono eseguite al più $m+n$ volte.

*Complessità spaziale* \
L'algoritmo richiede $Theta(m dot n)$ per l'istanzazione delle variabili, in particolare della tabella `b`.
Per quanto riguarda lo spazio necessario per la pila dei contesti è necessario calcolare il valore massimo di contesti impilati. 
La chiamata ricorsiva a riga 3 e succeduta da un'istruzione, quindi non è una ricorsione in coda. 
Nonostante la presenza di una chiamata ricorsiva non in coda, è necessario differenziare l'analisi quando si utilizza un compilatore ottimizzante e non.

*Analisi compilatore non ottimizzante:*
\ Il caso pessimo si riscontra con le chiamate a riga 5 e 7, in questi casi viene ridotto solamente il valore di o $j$ oppure $i$.  
Il numero massimo di contesti impilati nel caso pessimo è quindi $m + n$. 
La complessità è uguale a $O(m+n)$.

*Analisi compilatore ottimizzante:*
\ Dal punto precedente abbiamo appurato che il caso pessimo si verifica quando vengono chiamate le istruzioni alle righe 5 e 7. Tuttavia queste chiamate sono ricorsive in coda, se si utilizzasse un compilatore ottimizzante in questo caso la pila dei contesti rimarrebbe costante. 
Dobbiamo quindi analizzare il caso pessimo relativo al compilatore ottimizzante, che si riscontra quando viene eseguita la chiamata a riga 3 per tutti i valori di $i$ e $j$.\
Quindi in questo caso la complessità spaziale è $O(min(m,n))$

*La complessità spaziale totale dell'algoritmo è*
- Compilatore non ottimizzante: $Theta(m dot n)+O(m+n)=Theta(m dot n)$
- Compilatore ottimizzante: #h(.08cm) $Theta(m dot n) + O(min(m,n))=Theta(m dot n)$

\ \ \
Compito 1
- Descrivere un problema (presente in letteratura o ideato dal gruppo di lavoro) che possa essere risolto da
  un algoritmo realizzato seguendo il paradigma della
  programmazione dinamica
- Dimostrare l’applicabilità del paradigma della
  programmazione dinamica a suddetto problema
- Scrivere lo pseudocodice di un algoritmo che operi
  secondo il paradigma della programmazione dinamica
  al fine di determinare il valore di una soluzione ottima
  e lo pseudocodice di un ulteriore algoritmo che sfrutti
  le informazioni salvate dal primo al fine di costruire
  una soluzione ottima
- Effettuare l’analisi asintotica del tempo di esecuzione e
  dell’occupazione di memoria del primo algoritmo di cui
  al punto precedente 


Generazione soluzione \
TEMPI: $O(m dot n)$ \
SPAZIO: $O(m  dot n)$

Stampa \
Tempi: $O(m + n)$
- Compilatore non ottimizzante: $Theta(m dot n)+O(m+n)=Theta(m dot n)$
- Compilatore ottimizzante: #h(.08cm) $Theta(m dot n) + O(min(m,n))=Theta(m dot n)$


  
= Possibili migliorie del codice


= Implementazione

- Questione compilatori C++, come attivare ricorsione in coda... (perchè C++ come abbiamo misurato memoria di picco tralasciando overhead...)

\ \ \ 
Bibliografia provvisoria:
- Longest common subsequence; Wikipedia https://en.wikipedia.org/wiki/Longest_common_subsequence
- T. H. CORMEN, C. E. LEISERSON, R. L. RIVEST, C. STEIN; INTRODUZIONE AGLI ALGORITMI E STRUTTURE DATI; QUARTA EDIZIONE; MCGRAW-HILL; 2023
- 1143. Longest Common Subsequence; Leetcode: https://leetcode.com/problems/longest-common-subsequence/description/ 



#pagebreak()

// #show math.equation: set text(font: "TeX Gyre Pagella Math")
//#show math.equation: set text(font: "Libertinus Math", spacing: 0.4em, size:14pt)
//#show math.equation: set text(font: "TeX Gyre Termes Math", spacing: 0.4em, size: 14pt)
#show math.equation: set text(font: "New Computer Modern Math", spacing: 0.4em, size:13.5pt)

*Progetto* \
Ambito della programmazione dinamica, problema già trattato di cui dobbiamo codificare l'algoritmo oppure un problema fatto da noi (aggiugnere qualcosa di personale). \
Problema da risolvere con paradigma della programmazione dinamica, dimostrare che sia risolvibile con la programmazione dinamica, dimostrando invece che un divide-et-impera causerebbe risoluzione degli stessi problemi più volte. \
Una volta dimostrata applicabilità si fa pseudocodice dell'algoritmo (molto breve), analisi asintotica tempo e spazio dell'algoritmo bottom-up. \

Compito 2: realizzare gli algoritmi con eventuali modifiche per efficienza o personalizzazioni.

Compito 3: sottoporre gli algoritmi ad una sperimentazione runnando con dimensioni diverse su tempo e spazio (analisi grafica per dimostrare come varia)

Tabelle prodotte dal primo algoritmo e usate dal secondo, devono avere una rappresentazione testuale comprensibile. \
Presentazione del lavoro con powerpoint in 10 minuti massimo. \
Nella demo si chiede di provare dinamicamente il codice. \

// #align(center)[= Programmazione dinamica] #v(.1cm)
Nuovo paradigma di sintesi di algoritmi, l'unico visto finora era il divide-et-impera, entrambi risolvono i problemi combinando le soluzioni di sottoproblemi. \ L'approcio divide-et-impera è un approccio top-down che divide in sottoproblemi "indipendenti" ovvero risolti in modo indipendente l'uno dall'altro, può succedere che sottoproblemi comuni siano risolti più volte (aumenta l'uso di memoria). \

La programmazione dinamica ha un approccio #underline[bottom-up], per cui si individuano tutti i problemi più piccoli e li si risolve andando poi man mano a comporre i problemi di dimensioni maggiori. \ Questo evita le ripetizioni nella risoluzione di sottoproblemi, le soluzioni dei sottoproblemi si memorizzano in una tabella e sono riutilizzate se si ripresenta lo stesso sottoproblema, la programmazione dinamica è per questo un metodo di soluzione tabulare. \ Si applica anche a sottoproblemi non indipendenti, dove due problemi non sono indipendenti se entrambi richiedono la soluzione di almeno un sottoproblema comune. \
Questo paradigma viene spesso applicato a problemi di ottimizzazione, i quali solitamente possono ammettere più soluzioni ottime. \ Con la programmazione dinamica si trova una sola soluzione ottima ed il valore della funzione obiettivo in corrispondenza di questa soluzione. \
\
La progettazione di un algoritmo con questo paradigma procede con 4 fasi: 
+ Caratterizzazione della struttura della soluzione ottima, dobbiamo descrivere il problema e questo deve esibire certe proprietà affinché si possa applicare la programmazione dinamica
+ Definizione ricorsiva del valore della soluzione ottima, bisogna poter scrivere in modo ricorsivo la soluzione
+ Calcolo del valore di una soluzione ottima con una strategia bottom-up che porta alla scrittura di un algoritmo iterativo. 
+ Se ci interessa trovare una soluzione ottima procediamo con il passo opzionale di costruire una soluzione ottima a partire dalle informazioni calcolate al punto precedente (quelle salvate in tabelle).
\